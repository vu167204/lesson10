import axios from 'axios'
export default axios.create({
    baseURL:"https://666c5a5b49dbc5d7145dbb07.mockapi.io/nhvapi/nhvv/"
})